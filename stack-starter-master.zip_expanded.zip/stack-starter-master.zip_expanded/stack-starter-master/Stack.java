
/**

 * This is the class to implement a stack.

 * 

 * The stack should hold string data and have a constructor with one

 * integer parameter (the size of the stack).

 *

 * You have the freedom to choose how to implement your stack using any

 * of the data structures we have already studied (arrays, ArrayLists,

 * linked lists, binary trees, etc.).

 * 

 * @author Michael Ida

 *

 */

import java.util.*;

public class Stack implements StackInterface {


    protected String arr[];

    protected int top, size, len;


   public Stack(int n)

    {

        size = n;

        len = 0;

        arr = new String[size];

        top = -1;

    }

    

    public boolean isEmpty()

    {

        return top == -1;

    }

    

    public boolean isFull()

    {

        return top == size -1 ;        

    }

    

    public int getSize(){

        return len ;

    }

   

    public String peek(){

        if( isEmpty() )

            throw new NoSuchElementException("Underflow Exception");

        return arr[top];

    }

    

    public boolean push(String i){

        if(top + 1 >= size){

            return false;

        }

        else{

            arr[++top] = i;

        len++ ;

        return true;

        }

    }

    

    public String pop(){

        if( isEmpty() )

            throw new NoSuchElementException("Underflow Exception");

        len-- ;

        return arr[top--]; 

    }    

    public void printStack(){

        System.out.print("\nStack = ");

        if (len == 0)

        {

            System.out.print("Empty\n");

            return ;

        }

        for (int i = top; i >= 0; i--)

            System.out.print(arr[i]+" ");

        System.out.println();

    }    

}

